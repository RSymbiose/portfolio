/*
Ce programme permet de jouer au jeu du puissance 4 dans le terminal,
j'ai dû modifier le programme principal en consigne afin de pouvoir
au mieux faire correspondre mon jeu à ma maquette.

Programme réalisé par Jules AUTRET 1A1
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

//Définition des constantes

char PION_A[4] = "●";
char PION_B[4] = "○";

char PION_A_1[4] = "●";
char PION_B_1[4] = "○";

char PION_A_2[4] = "■";
char PION_B_2[4] = "□";

char PION_A_3[4] = "▲";
char PION_B_3[4] = "△";

char VIDE[4] = " ";
char INCONNU[4] = " ";
char MUR[4] = "█";

#define NBLIG 6
#define NBCOL 7
const int COLONNE_DEBUT = NBCOL / 2;

//Définition du type grille

typedef char *Grille[NBLIG][NBCOL];
Grille g;

//Définition des procédures

void initGrille(Grille);
void afficher(Grille, char[4], int);
void jouer(Grille, char[4], int*, int*);
void finDePartie(char[4]);

//Définition des procédures hors consigne mais utile dans le respect de la maquette

int menu(char[4], char[4]);
void customisation(char[4], char[4]);
void initGrilleExpert(Grille, Grille);

//Définition des fonctions

bool grillePleine(Grille);
int choisirColonne(Grille, char[4], int);
int trouverLigne(Grille, int);
bool estVainqueur(Grille, int, int);

int main() {
    char vainqueur[4];
    int ligne, colonne, choixMenu;
    Grille gExpert;

    initGrille(g);
    initGrille(gExpert);

    choixMenu = menu(PION_A, PION_B);

    if (choixMenu != -1) {
        strcpy(vainqueur, INCONNU);
        afficher(g, PION_A, COLONNE_DEBUT);

        //Boucle de jeu
        while (strcmp(vainqueur, INCONNU) == 0 && !grillePleine(g)){
            if (choixMenu == 1) {
                jouer(gExpert, PION_A, &ligne, &colonne);
                initGrilleExpert(g, gExpert);
                afficher(gExpert, PION_B, COLONNE_DEBUT);
            }
            else {
                jouer(g, PION_A, &ligne, &colonne);
                afficher(g, PION_B, COLONNE_DEBUT);
            }
            if (estVainqueur(g, ligne, colonne)){
                strcpy(vainqueur, PION_A);
            }
            else if (!grillePleine(g)){
                if (choixMenu == 1) {
                    jouer(gExpert, PION_B, &ligne, &colonne);
                    initGrilleExpert(g, gExpert);
                    afficher(gExpert, PION_A, COLONNE_DEBUT);
                }
                else {
                    jouer(g, PION_B, &ligne, &colonne);
                    afficher(g, PION_A, COLONNE_DEBUT);
                }

                if (estVainqueur(g, ligne, colonne)){
                    strcpy(vainqueur, PION_B);
                }
            }
        }

        //Affiche la fin avec le vainqueur

        finDePartie(vainqueur);
    }

    return 0;
}

// Init Grille

void initGrille(Grille tab) {
    for (int i = 0; i < NBLIG; i++) {
        for (int j = 0; j < NBCOL; j++) {
            tab[i][j] = VIDE;
        }
    }
}

// Affiche la grille

void afficher(Grille tab, char pion[4], int colonne) {
    system("clear");
    for (int i = 0; i < colonne * 4 + 3; i++) {
        printf(" ");
    }
    printf("%s", pion);
    printf("\n");
    int k = 0;
    for (int i = 0; i < NBLIG; i++) {
        if (i != 0) {
            printf("\n");
        }
        printf("%s%s", MUR, MUR);
        int indice = 3;
        for (int j = 0; j < NBCOL * 4 - 1; j++) {
            if (j == indice && j != NBCOL * 4 - 1) {
                printf("|");
                indice = indice + 4;
            }
            else if (j % 2 == 0) {
                printf("_");
            }
            else {
                printf("%s", tab[i][k % NBCOL]);
                k++;
            }
        }
        printf("%s%s", MUR, MUR);
    }
    printf("\n");
    for (int i = 0; i < NBCOL * 4 + 3; i++) {
        printf("%s", MUR);
    }
    printf("\n");
    for (int i = 0; i < NBCOL * 4 + 3; i++) {
        if (i == 0 || i == NBCOL * 4 + 2) {
            printf("%s", MUR);
        }
        else {
            printf(" ");
        }
    }
}

// Vérifie si la grille est pleine

bool grillePleine(Grille tab) {
    bool plein = true;
    for (int i = 0; i < NBLIG; i++) {
        for (int j = 0; j < NBLIG; j++) {
            if (tab[i][j] == VIDE) {
                plein = false;
            }
        }
    }
    return plein;
}

// Affiche le vainqueur de la partie

void finDePartie(char pion[4]) {
    printf("\n\nFélicitation à %s qui a gagné !\n\n", pion);
}

/* Permet au joueur de choisir la colonne qu'il souhaite jouer à l'aide
des touches q et d */

int choisirColonne(Grille tab, char pion[4], int colonneDb) {
    int choix;
    choix = colonneDb;
    bool aChoisi = false;
    char touche, rc;
    while (!aChoisi) {
        printf("\n\nAppuyez sur q (gauche), d (droite) ou bien Espace (valider): ");
        scanf("%c%c", &touche, &rc);
        if (touche == 'q' || touche == 'Q') {
            choix = (choix - 1 < 0) ? 0 : choix - 1;
            afficher(tab, pion, choix);
        }
        else if (touche == 'd' || touche == 'D') {
            choix = (choix + 1 > NBCOL - 1) ? NBCOL - 1 : choix + 1;
            afficher(tab, pion, choix);
        }
        else if (touche == ' ') {
            aChoisi = true;
        }
        else {
            continue;
        }
    }
    return choix;
}

// Permet de renvoyer le numéro de la première ligne libre et -1 si elle est pleine

int trouverLigne(Grille tab, int colonne) {
    int ligne;
    ligne = -1;
    for (int i = 0; i < NBLIG; i++) {
        if (strcmp(tab[i][colonne], " ") == 0) {
            ligne = i;
        }
    }
    return ligne;
}

// Permet de jouer

void jouer(Grille tab, char pion[4], int *ligne, int *colonne) {
    bool peutJouer = false;
    while (!peutJouer) {
        *colonne = choisirColonne(tab, pion, COLONNE_DEBUT);
        *ligne = trouverLigne(tab, *colonne);
        if (*ligne != -1) {
            peutJouer = true;
        }
    }
    g[*ligne][*colonne] = pion;
}

// Vérifie si le joueur a gagné

bool estVainqueur(Grille g, int ligne, int colonne) {
    bool vainqueur = false;
    int compteur = 0;
    int i = 0;
    int j = 0;
    // Teste si la ligne est gagnante
    for (i = 0; i < NBCOL; i++) {
        if (strcmp(g[ligne][i], g[ligne][colonne]) == 0) {
            compteur++;
        }
        else {
            compteur = 0;
        }
        if (compteur == 4) {
            vainqueur = true;
        }
    }
    // Teste si la colonne est gagnante
    compteur = 0;
    for (i = 0; i < NBLIG; i++) {
        if (strcmp(g[i][colonne], g[ligne][colonne]) == 0) {
            compteur++;
        }
        else {
            compteur = 0;
        }
        if (compteur == 4) {
            vainqueur = true;
        }
    }
    // Teste si la diagonale descendante est gagnante
    compteur = 0;
    int pointDepartI, pointDepartJ;
    pointDepartI = (colonne < ligne) ? ligne - colonne : 0;
    pointDepartJ = (ligne < colonne) ? colonne - ligne : 0;
    for (i = pointDepartI, j = pointDepartJ; i < NBLIG && j < NBCOL; i++, j++) {
        if (strcmp(g[i][j], g[ligne][colonne]) == 0) {
            compteur++;
        }
        else {
            compteur = 0;
        }
        if (compteur == 4) {
            vainqueur = true;
        }
    }
    // Teste si la diagonale montante est gagnante
    compteur = 0;
    pointDepartI = (colonne <= NBLIG - ligne - 1) ? ligne + colonne : NBLIG - 1;
    pointDepartJ = (ligne < NBCOL - colonne - 1) ? 0 : ligne - (NBCOL - colonne - 2);
    for (i = pointDepartI, j = pointDepartJ; i >= 0 && j < NBCOL; i--, j++) {
        if (strcmp(g[i][j], g[ligne][colonne]) == 0) {
            compteur++;
        }
        else {
            compteur = 0;
        }
        if (compteur == 4) {
            vainqueur = true;
        }
    }
    return vainqueur;
} 

/*
╔══════════════════════════════════════════════════════════╗
║      ___       _                                _  _     ║
║     / _ \_   _(_)___ ___  __ _ _ __   ___ ___  | || |    ║
║    / /_)/ | | | / __/ __|/ _` | '_ \ / __/ _ \ | || |_   ║
║   / ___/| |_| | \__ \__ \ (_| | | | | (_|  __/ |__   _|  ║
║   \/     \__,_|_|___/___/\__,_|_| |_|\___\___|    |_|    ║
║  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   ║
║                                                          ║
║                   Jouer (Appuyer sur J)                  ║
║                                                          ║
║                Jouer Expert (Appuyer sur E)              ║
║                                                          ║
║               Customisation (Appuyer sur C)              ║
║                                                          ║
║                  Quitter (Appuyer sur Q)                 ║
║                                                          ║
║                                                          ║
║                   Par Jules AUTRET 2022                  ║
╚══════════════════════════════════════════════════════════╝
*/

// Permet d'afficher le menu du puissance 4

int menu(char pionA[4], char pionB[4]) {
    char choix, rc;
    bool aChoisi = false;
    int choixMenu = 0;

    while (!aChoisi) {
        system("clear");

        printf("\
╔══════════════════════════════════════════════════════════╗\n\
║      ___       _                                _  _     ║\n\
║     / _ \\_   _(_)___ ___  __ _ _ __   ___ ___  | || |    ║\n\
║    / /_)/ | | | / __/ __|/ _` | '_ \\ / __/ _ \\ | || |_   ║\n\
║   / ___/| |_| | \\__ \\__ \\ (_| | | | | (_|  __/ |__   _|  ║\n\
║   \\/     \\__,_|_|___/___/\\__,_|_| |_|\\___\\___|    |_|    ║\n\
║  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   ║\n\
║                                                          ║\n\
║                   Jouer (Appuyer sur J)                  ║\n\
║                                                          ║\n\
║                Jouer Expert (Appuyer sur E)              ║\n\
║                                                          ║\n\
║               Customisation (Appuyer sur C)              ║\n\
║                                                          ║\n\
║                  Quitter (Appuyer sur Q)                 ║\n\
║                                                          ║\n\
║                                                          ║\n\
║                   Par Jules AUTRET 2022                  ║\n\
╚══════════════════════════════════════════════════════════╝\n\n");
        printf("Choix : ");
        scanf("%c%c", &choix, &rc);

        switch (choix) {
            case 'J':
            case 'j':
                aChoisi = true;
                break;
            case 'E':
            case 'e':
                aChoisi = true;
                choixMenu = 1;
                break;
            case 'C':
            case 'c':
                customisation(pionA, pionB);
                break;
            case 'Q':
            case 'q':
                aChoisi = true;
                choixMenu = -1;
                break;
            default:
                break;
        }
    }   
    return choixMenu;
}

// Permet d'afficher le menu de personnalisation

void customisation(char pionA[4], char pionB[4]) {
    system("clear");
    char choix, rc;
    printf("\
╔══════════════════════════════════════════════════════════╗\n\
║      ___       _                                _  _     ║\n\
║     / _ \\_   _(_)___ ___  __ _ _ __   ___ ___  | || |    ║\n\
║    / /_)/ | | | / __/ __|/ _` | '_ \\ / __/ _ \\ | || |_   ║\n\
║   / ___/| |_| | \\__ \\__ \\ (_| | | | | (_|  __/ |__   _|  ║\n\
║   \\/     \\__,_|_|___/___/\\__,_|_| |_|\\___\\___|    |_|    ║\n\
║  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=   ║\n\
║                                                          ║\n\
║                Choisissez un thème de jeu :              ║\n\
║                                                          ║\n\
║                         %s / %s : 1                        ║\n\
║                                                          ║\n\
║                         %s / %s : 2                        ║\n\
║                                                          ║\n\
║                         %s / %s : 3                        ║\n\
║                                                          ║\n\
║                                                          ║\n\
║                   Par Jules AUTRET 2022                  ║\n\
╚══════════════════════════════════════════════════════════╝\n\n", PION_A_1, PION_B_1, PION_A_2, PION_B_2, PION_A_3, PION_B_3);
    printf("Choix : ");
    scanf("%c%c", &choix, &rc);
    switch (choix) {
        case '1':
            strcpy(pionA, PION_A_1);
            strcpy(pionB, PION_B_1);
            break;
        case '2':
            strcpy(pionA, PION_A_2);
            strcpy(pionB, PION_B_2);
            break;
        case '3':
            strcpy(pionA, PION_A_3);
            strcpy(pionB, PION_B_3);
            break;
        default:
            printf("Choix invalide\n");
            customisation(pionA, pionB);
            break;
    }
}

// Initialise la grille experte pour qu'elle affiche toujours le même pion

void initGrilleExpert(Grille tab, Grille expert) {
    for (int i = 0; i < NBLIG; i++) {
        for (int j = 0; j < NBCOL; j++) {
            if (tab[i][j] == PION_B) {
                expert[i][j] = PION_A;
            }
            else {
                expert[i][j] = tab[i][j];
            }
        }
    }
}