#/bin/bash

if [ $# -eq 2 ]; then
    if [ ! -d "/Docker/$(whoami)/$1/pdf" ]; then
        mkdir -p "/Docker/$(whoami)/$1/pdf";
    fi

    nom=$(tr -s ' ' '-' <<< "$2")
    printf "\n\n\n $nom \n\n\n" 

    docker run --rm -v "/Docker/$(whoami):/work" sae103-html2pdf "html2pdf \"sites/$2.html\" \"sites/pdf/$nom.pdf\""
else
    echo "Utilisation: ./convert.sh [dossier-images] [nom-region]"
fi

