#!/bin/bash

if [ $# -eq 1 ]; then
    if [ ! -d /Docker/$(whoami)/$1/output ]; then
        mkdir -p /Docker/$(whoami)/$1/output;
    fi

    for photo in $1/*.svg; do
        nomSvg=$(echo $photo | cut -d '/' -f2)
        nomFichier=$(echo $nomSvg | cut -d '.' -f1)
        echo /Docker/$(whoami)/$1/output/$nomFichier.png
        docker run --rm -v "/Docker/$(whoami)/$1:/work" sae103-imagick "magick $nomSvg -resize 200x200^ -gravity North -extent 200x185 -colorspace Gray ./output/$nomFichier.png"
    done
else
    echo "Utilisation: ./avatars.sh [dossier-images]"
fi

