#/bin/bash

while read line; do
    nom=$(echo $line | cut -d " " -f1)
    echo "https://bigbrain.biz/$i"
    docker run --rm -v "/Docker/$(whoami)/qrcode:/qrcode" sae103-qrcode qrcode -o /qrcode/"$nom" "https://bigbrain.biz/$nom"
done < regions.conf

docker container prune -f
