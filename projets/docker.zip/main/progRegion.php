#!/usr/bin/php

<?php
	if ($argc > 1) {
		$lien = $argv[1];

		$cptfichier = 0;
		$cptelement = 0;
		$cptcontenu = 0;
		$cptcontenuT = 0;

		$trouve = false;
		$trouvetab = false;
		$end = false;
		$endT = false;
		$checkAv = false;

		$dir = "results";

		if (!file_exists($dir)) {
			mkdir($dir);
		}

		$fichiertexte = fopen($dir . "/texte.dat", "w");
		fwrite($fichiertexte, "{ ");
		$fichiertableau = fopen($dir . "/tableau.dat", "w");
		fwrite($fichiertableau, "{ ");
		$fichiercomm = fopen($dir . "/comm.dat", "w");
		fwrite($fichiercomm, "{ ");

		$fichiers = scandir($lien);
		$fichiers = array_slice($fichiers, 2);

		foreach ($fichiers as $f) {
			$chemin = $lien . "/" . $f;
			$contenu = file($chemin);

			fwrite($fichiertexte, "\"" . str_replace(".txt", "", $f) . "\": [{");
			fwrite($fichiertableau, "\"" . str_replace(".txt", "", $f) . "\": [{");
			fwrite($fichiercomm, "\"" . str_replace(".txt", "", $f) . "\": [{");

			$cptcontenuT = 0;

			$checkAv = false;
			$endT = false;

			$cptTitre = 1;
			$cptSousTitre = 1;
			$cptTexte = 1;
			foreach ($contenu as $c) {

				// Texte

				if (strpos(strtolower($c), "debut_texte") !== false || strpos(strtolower($c), "début_texte") !== false) {
					fwrite($fichiertexte, "\"texte" . $cptTexte . "\":\"");
					$trouve = true;
					$cptTexte++;
				}
				else if (strpos(strtolower($c), "fin_texte") !== false) {
					$trouve = false;
					$endT = true;
				}
				else if (strpos(strtolower($c), "sous_titre") !== false) {
					$sousTitre = explode("=", $c);
					fwrite($fichiertexte, "\"sous_titre" . $cptSousTitre . "\":\"" . rtrim($sousTitre[1]) . "\",");
					$cptSousTitre++;
				}
				else if (strpos(strtolower($c), "titre") !== false) {
					$titre = explode("=", $c);
					fwrite($fichiertexte, "\"titre" . $cptTitre . "\":\"" . rtrim($titre[1]) . "\",");
					$cptTitre++;
				}
				else if ($trouve) {
					$dernierTexte = rtrim($c);
					fwrite($fichiertexte, rtrim($c));
				}

				if ($cptcontenuT + 2 < count($contenu)) {
					if (strpos(strtolower($contenu[$cptcontenuT + 2]), "debut_stats") !== false || strpos(strtolower($contenu[$cptcontenuT + 2]), "début_stats") !== false) {
						fwrite($fichiertexte, "\"");
						$endT = false;
						$checkAv = true;
					}
					else if ($endT && ! $checkAv) {
						fwrite($fichiertexte, "\",");
						$endT = false;
					}
				}

				$cptcontenuT++;

				// Pour le tableau

				if (strpos(strtolower($c), "fin_stats") !== false) {
					$trouvetab = false;
					$end = true;
				}

				if ($end && $cptcontenu > 0) {
					fwrite($fichiertableau, "}]");
					$trouvetab = false;
					$end = false;
					$cptcontenu = 0;
				}
				else if ($trouvetab && $cptcontenu > 0){
					fwrite($fichiertableau, "}],");
				}

				if (strpos(strtolower($c), "debut_stats") !== false || strpos(strtolower($c), "début_stats") !== false) {
					$trouvetab = true;
				}
				else if ($trouvetab) {
					$cptcontenu++;
					$tabpart = explode(",", $c);
					fwrite($fichiertableau, "\"" . rtrim($tabpart[0]) . "\": [{");
					fwrite($fichiertableau, "\"stat1\":" . rtrim($tabpart[1]) . ",");
					fwrite($fichiertableau, "\"stat2\":" . rtrim($tabpart[2]) . ",");
					fwrite($fichiertableau, "\"stat3\":" . rtrim($tabpart[3]) . ",");
					fwrite($fichiertableau, "\"stat4\":" . rtrim($tabpart[4]) . ",");
					$evolution = rtrim($tabpart[2]) / rtrim($tabpart[4]) * 100;
					$evolution -= 100;
					fwrite($fichiertableau, "\"evolution\":" . $evolution);
				}

				// Pour les meilleurs employés

				if (strpos(strtolower($c), "meilleurs:") !== false) {
					$liste_nom = array_slice(explode(":", $c), 1);
					$nom = implode("", $liste_nom);
					$nom = explode(",", $nom);
					foreach ($nom as &$n) {
						$n = str_replace("K€", "", $n);
						$liste_n = preg_split("/[\/|=]/", $n);
						if (count($liste_n) == 2) {
							fwrite($fichiercomm, "\"" . rtrim($liste_n[0]) . "\": [{");
							fwrite($fichiercomm, "\"code\": \"NULL\", ");
							fwrite($fichiercomm, "\"argent\":" . rtrim($liste_n[1]));
						}
						else {
							fwrite($fichiercomm, "\"" . rtrim($liste_n[1]) . "\": [{");
							fwrite($fichiercomm, "\"code\":\"" . rtrim($liste_n[0]) . "\", ");
							fwrite($fichiercomm, "\"argent\":" . rtrim($liste_n[2]));
						}
						if ($cptelement !== count($nom) - 1) {
							fwrite($fichiercomm, "}], ");
							$cptelement++;
						}
						else {
							$cptelement = 0;
							fwrite($fichiercomm, "}] ");
						}
					}
				}
			}
			if ($cptfichier !== count($fichiers) - 1) {
				fwrite($fichiertexte, "}], ");
				fwrite($fichiertableau, "}], ");
				fwrite($fichiercomm, "}], ");
			}
			else {
				fwrite($fichiertexte, "}] ");
				fwrite($fichiertableau, "}] ");
				fwrite($fichiercomm, "}] ");
			}
			$cptfichier++;
		}
		fwrite($fichiertexte, "}");
		fwrite($fichiertableau, "}");
		fwrite($fichiercomm, "}");
		
		fclose($fichiertexte);
		fclose($fichiertableau);
		fclose($fichiercomm);

		echo "Les fichiers ont été générés avec succès !\n";
	} else {
		echo "Aucun argument: utilisation: ./progRegion.php [dossier]\n";
	}
?>
