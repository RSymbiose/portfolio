#!/usr/bin/php
<?php
if ($argc == 7) {
    $text = file_get_contents($argv[2] . '/texte.dat');
    $text = json_decode($text, true);
    $tableau = file_get_contents($argv[2] . '/tableau.dat');
    $tableau = json_decode($tableau, true);
    $comm = file_get_contents($argv[2] . '/comm.dat');
    $comm = json_decode($comm, true);

    $region = fopen($argv[6] . "/" . $argv[1] . ".txt", "r");
    $regionconf = file("regions.conf");

    while (!feof($region)) {
        $line = fgets($region);
        if (strpos(rtrim(strtoupper($line)), "CODE=") !== false) {
            $code = substr($line, 5);
        }
    }
} else {
    echo "Utilisation: ./html.php [region] [dossier-resultats] [dossier-photos] [dossier-logos] [dossier-qrcode] [dossier-regions]";
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="style.css">
    <title>Relevé de la région <?php echo $argv[1] ?></title>
</head>

<body>
    <main>
        <section>
            <header>
                <nav>
                    <?php echo "<a><img draggable=\"false\" src=\"../" . $argv[4] . "/" . rtrim(strtoupper($code)) . ".png\"></a>\n";?>
                    <h3>Relevé de la région <?php echo $argv[1] ?></h3>
                </nav>

            </header>
            <aside>
                <h3>Nom de la région <br><?php echo rtrim($argv[1]) ?></h3>
                <?php 
                foreach ($regionconf as $key => $value) {
                    $value = explode("/", $value);
                    if (rtrim($value[0]) == strtoupper(rtrim($code))) {
                        echo "<h3>Population <br>" . $value[2] . "</h3>\n";
                        echo "<h3>Superficie <br>" . $value[3] . "km²</h3>\n";
                        echo "<h3>Nombre de départements <br>" . rtrim($value[4]) . "</h3>\n";
                        break;
                    }
                }
                ?>
            </aside>

        </section>

        <section>
            <h1>Résultats trimestriels <?php echo rtrim(str_pad(round(date("m")/4, 0) + 1, 2, '0', STR_PAD_LEFT) . "-" . date("Y")) ?></h1>
            <?php
            foreach ($text[$argv[1]][0] as $key => $value) {
                if (strpos($key, "sous_titre") !== false) {
                    echo "<h3>" . $value . "</h3>\n";
                } else if (strpos($key, "titre") !== false) {
                    echo "<h2>" . $value . "</h2>\n";
                } else {
                    echo "<p>" . $value . "</p>\n";
                }
            }
            ?>
            <table>
                <thead>
                    <tr>
                        <th>Nom du produit</th>
                        <th>Ventes du trimestre</th>
                        <th>Chiffre d’affaires du trimestre</th>
                        <th>Ventes du même trimestre année précédente</th>
                        <th>CA du même trimestre année précédente</th>
                        <th>Evolution de CA en %age et en valeur absolue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($tableau[$argv[1]][0] as $key => $value) {
                        echo "<tr>\n";
                        echo "<td>" . $key . "</td>\n";
                        echo "<td>" . $value[0]["stat1"] . "</td>\n";
                        echo "<td>" . $value[0]["stat2"] . "</td>\n";
                        echo "<td>" . $value[0]["stat3"] . "</td>\n";
                        echo "<td>" . $value[0]["stat4"] . "</td>\n";
                        if ($value[0]["evolution"] < 0) {
                            echo "<td class=\"evoMoins\">" . $value[0]["evolution"] . "</td>\n";
                        } else {
                            echo "<td class=\"evoPlus\">" . $value[0]["evolution"] . "</td>\n";
                        }
                        echo "</tr>\n";
                    }
                    ?>
                </tbody>
            </table>
        </section>

        <section>
            <h1>Nos meilleurs vendeurs du trimestre</h1>
            <div>
                <?php 
                $files = glob($argv[3] . "/output/*.png");
                foreach ($comm[$argv[1]][0] as $key => $value) {
                    $file = array_rand($files);
                    echo "<figure><img draggable=\"false\" src=\"../" . $files[$file] . "\" height=\"200\" width=\"200\">\n" . "<figcaption>" . $key . ", CA : " . $value[0]["argent"] . "K€</figcaption>\n" . "</figure>\n";
                }
                ?>
            </div>
        </section>

        <section>
            <?php echo "<h3>Lien vers la société Face Co : https://face.co/" . strtoupper(rtrim($code)) . "</h3>\n"; ?>
            <?php echo "<img draggable=\"false\" src=\"../" . $argv[5] . "/" . strtoupper(rtrim($code)) . "\">\n"; ?>
            <?php echo "<h4>Document généré le " . date("Y/m/d") . " à " . date("H:i:s") . "</h4>\n"; ?>
        </section>

    </main>
</body>

</html>