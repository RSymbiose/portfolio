#!/bin/bash

# Permet d'autoriser l'exécution des scripts
chmod +x avatars.sh
chmod +x html2pdf.sh
chmod +x qrcode.sh
chmod +x progRegion.php
chmod +x html.php

# Main
if [ $# -eq 3 ]; then

    # Créer de nouveau dossier propre
    mkdir -p PDF;
    mkdir -p /Docker/$(whoami);

    # Copie toutes les données nécéssaires dans le dossier de travail Docker
    cp -p regions.conf /Docker/$(whoami)
    cp -p progRegion.php /Docker/$(whoami)
    cp -p html.php /Docker/$(whoami)
    cp -p -r "$1" /Docker/$(whoami)
    cp -p -r "$2" /Docker/$(whoami)
    cp -p -r "$3" /Docker/$(whoami)
    cp -p -r sites /Docker/$(whoami)

    # Lance la génération des fichiers .dat
    echo "Création des différents fichiers JSON des régions..."
    docker run --rm -v "/Docker/$(whoami):/work" sae103-php php -f progRegion.php "$1"

    printf "\n"

    # Convertit les avatars en noir et blanc et au format 200x200
    echo "Convertion des avatars..."
    ./avatars.sh $2

    printf "\n"

    # Génére les QRCodes
    echo "Création des QR Codes..."
    ./qrcode.sh

    printf "\n"

    # Génére les pages régions au format HTML
    for texte in $1/*.txt; do
        region=$(echo $texte | cut -d '/' -f2 | cut -d '.' -f1)
        echo "Création de la page HTML de $region..."
        nom=$(tr -s ' ' '-' <<< "$region")
        docker run --rm -v "/Docker/$(whoami):/work" sae103-php php -f html.php "$region" results "$2" "$3" qrcode "$1" > "/Docker/$(whoami)/sites/$nom.html"
    done

    printf "\n"

    # Génére les PDF
    for site in /Docker/$(whoami)/sites/*.html; do
        region=$(echo $site | cut -d '/' -f5 | cut -d '.' -f1)
        echo "Création du PDF de $region..."
        ./html2pdf.sh sites "$region"

        nom=$(tr -s ' ' '-' <<< "$region")
        mv "/Docker/$(whoami)/sites/pdf/$nom.pdf" "PDF/$nom.pdf"
    done

    tar -czf "PDF.tar.gz" PDF

    # Supprime le dossier des PDF
    rm -r -f PDF

    # Supprime les fichiers Docker afin de ne pas prendre de place inutilemment
    rm -r -f /Docker

else
    echo "Utilisation: ./execution.sh [dossier-regions] [dossier-photos] [dossier-logos]"
fi