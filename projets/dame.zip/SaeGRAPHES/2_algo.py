#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Crée le 10/02/2021

Auteur : Jacovetti Romain, Autret Jules, Saleck Evan

Description : Probleme des 8 reines
Algorithme de backtracking De Niklaus Wirth

"""


def reines(n, i, a, b, c):
    if i < n: # On est pas encore arrivé à la fin de la grille
        for j in range(n): # On parcourt les colonnes
            if j not in a and i + j not in b and i - j not in c: # On vérifie que la reine n'est pas sur une autre reine
                yield from reines(n, i + 1, a + [j], b + [i + j], c + [i - j]) # On ajoute la reine à la liste des reines
    else:
        yield a


# Teste les performances de l'algorithme
def run():
    nb = 0
    taille = 12
    for solution in reines(taille, 0, [], [], []):
        nb += 1
    return [nb, 0]