#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 10 11:16:59 2023

@author: jautret
"""

import time
import algorithme1
import algorithme2
import algorithme3

def test_algorithm(algorithm):
    start_time = time.time()
    result = algorithm()
    end_time = time.time()
    return (result[0], result[1], end_time - start_time)

results = [test_algorithm(algorithm) for algorithm in [algorithme1.run, algorithme2.run, algorithme3.run]]

for i, (result, iterations, elapsed_time) in enumerate(results):
    print(f"Algorithme {i + 1}:")
    print(f"\tRésultat: {result}")
    print(f"\tTemps: {elapsed_time:.6f} secondes")
    print(f"\tItérations: {iterations}")
