#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Crée le 10/02/2021

Auteur : Jacovetti Romain, Autret Jules, Saleck Evan

Description : Probleme des 8 reines
Algorithme de backtracking 
"""

def resol_huit_reines(echiquier, lig, n, res, iterations): #Permet de résoudre le problème des 8 reines
    # Cette partie du code permet de compter le nombre de solutions
    if lig == n:
        res[0] += 1
        return
    
    #boucle qui permet de parcourir les colonnes
    for i in range(n):
        iterations[0] += 1
        if is_valid(echiquier, lig, i, n, iterations):
            echiquier[lig][i] = 1
            resol_huit_reines(echiquier, lig + 1, n, res, iterations)
            echiquier[lig][i] = 0
# Cette fonction permet de vérifier si la reine peut être placée sur echiquier[lig][col]
def is_valid(echiquier, lig, col, n, iterations):
    for i in range(lig):
        iterations[0] += 1
        if echiquier[i][col] == 1:
            return False
    i = lig - 1
    j = col - 1
    while i >= 0 and j >= 0:
        iterations[0] += 1
        if echiquier[i][j] == 1:
            return False
        i -= 1
        j -= 1
    i = lig - 1
    j = col + 1
    while i >= 0 and j < n:
        iterations[0] += 1
        if echiquier[i][j] == 1:
            return False
        i -= 1
        j += 1
    return True 

# Teste les performances de l'algorithme
def run():
    n = 8
    echiquier = [[0 for i in range(n)] for j in range(n)]
    res = [0]
    iterations = [0]
    resol_huit_reines(echiquier, 0, n, res, iterations)
    return [res[0], iterations[0]]

def compteur_de_soluces():
    solutions = []
    for i in range(1, 13):
        echiquier = [[0 for i in range(i)] for j in range(i)]
        res = [0]
        iterations = [0]
        resol_huit_reines(echiquier, 0, i, res, iterations)
        solutions.append(res[0])
    return solutions

if __name__ == '__main__':
    solutions = compteur_de_soluces()