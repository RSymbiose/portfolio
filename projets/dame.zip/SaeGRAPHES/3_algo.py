#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Crée le 10/02/2021

Auteur : Jacovetti Romain, Autret Jules, Saleck Evan

Description : Probleme des 8 reines

"""

def valide(echiquier, lig, col, iterations):
    # Regarde si la Reine peut être placée sur echiquier[lig][col]
    # Regarde sur la ligne à gauche
    for i in range(col):
        iterations[0] += 1
        if echiquier[lig][i] == 1:
            return False
 
    # Regarde sur la diagonale supérieure sur la gauche
    for i, j in zip(range(lig, -1, -1), range(col, -1, -1)):
        iterations[0] += 1
        if echiquier[i][j] == 1:
            return False
 
    # Regarde sur la diagonale inférieure sur la gauche
    for i, j in zip(range(lig, N, 1), range(col, -1, -1)):
        iterations[0] += 1
        if echiquier[i][j] == 1:
            return False
 
    return True
 
def nb_reines(echiquier, col, n, iterations):
    # Cas de base : Si toutes les reines sont placées
    if col >= n:
        return 1
 
    # Considère cette colonne et essaye de placer cette reine dans toutes les lignes
    total = 0
    for i in range(n):
        iterations[0] += 1
        if valide(echiquier, i, col, iterations):
            echiquier[i][col] = 1
            total += nb_reines(echiquier, col + 1, n, iterations)
            echiquier[i][col] = 0 # backtrack
 
    return total

N = 8
echiquier = [[0]*N for _ in range(N)]

# Teste les performances de l'algorithme
def run():
    iterations = [0]
    return [nb_reines(echiquier, 0, N, iterations), iterations[0]]


print(nb_reines(echiquier, 0, N, [0]))